In this homework, the public dataset for Titanic passenger is used, which is available in: 
https://github.com/caesar0301/awesome-public-datasets/blob/master/Datasets/titanic.csv.zip

Requirements
=====
matplotlib
pandas
numpy
re
csv

Usage
=====

pip install the required packages (list is in requirements.txt)
Download the titanic.csv.zip and put to the same folder with fetchdata.py.
Run fetchdata.py, and this will create 2 csv files: data-line.csv and data-hist csv.
Run linechart.py, and this will create linechart.png file.
Run histogram.py, and this will create histogram.png file.

fetchdata.py
-----
The python code is first doing the cleanup and formatting from titanic.csv to titanic_v2.csv file.

	Removes the extra commas in columns.
	Removes the double quotes in columns.
	Writes into titanic_v2.csv file.
	
Then, the code is creating data-line.csv file.

	Some age fields are null in raw data. This part is calculating the average of all ages, then fill the empty values with average value (29).
	Passenger id, survival and age is written into the file, which will be used in linechart.py
	
Last, the code is creating data-hist.csv file.

	Passenger id, survival and journey class is written into the file, which will be used in linechart.py
	
linechart.py
-----

	This code is getting a pivot table, count of survived/dead passengers by age from data-line.csv.
	The survival percentage is calculated and plotted into linechart.png by the x-axis of age.
	
histogram.py
-----

	This code is plotting the survival/death count in bar chart form by 3 classes of journey.
	Results are saved into histogram.png file.
	
	
	

