import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

df = pd.read_csv('data-hist.csv')
dfS = df.loc[lambda df: df.Survived == 1]
dfD = df.loc[lambda df: df.Survived == 0]

a=np.bincount(dfS.Pclass)[1:4]
b=np.bincount(dfD.Pclass)[1:4]



N = 3
surMeans = a
surStd = (0, 1, 2)

ind = np.arange(N)
width = 0.35

fig, ax = plt.subplots()
leg1 = ax.bar(ind, surMeans, width, color='green', yerr=surStd)

deadMeans = b
deadStd = (0, 1, 2)
leg2 = ax.bar(ind + width, deadMeans, width, color='red', yerr=deadStd)

ax.set_ylabel('Passenger Count')
ax.set_xlabel('Journey Classes')
ax.set_title('Titanic Survival Rate by Journey Classes')
ax.set_xticks(ind + width)
ax.set_xticklabels(('1st Class', '2nd Class', '3rd Class'))

ax.legend((leg1[0], leg2[0]), ('Survived', 'Dead'), loc='upper left')

plt.savefig('histogram.png')
