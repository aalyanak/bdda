import numpy as np
import re
import csv
import pandas as pd

input_file = open('titanic.csv', "rb")
reader = csv.reader(input_file)
output_file = open('titanic_v2.csv', "wb")
writer = csv.writer(output_file, delimiter=',')
for row in reader:
    a = [re.sub(',', r';', m) for m in row]
    b = [re.sub('"', r'', m) for m in a]
    writer.writerow(b)

input_file.close()
output_file.close()

raw_data = np.genfromtxt(
    'titanic_v2.csv',  # file name
    delimiter=',',  # column delimiter
    usecols=np.arange(0, 12),  # data type
    filling_values=0,       # fill missing values with 0
    dtype=['>i4', '>i4', '>i4', '>S100', '>S100', '>i8', '>i4', '>i4', '>S100', '>f8', '>S100', '>S100'],  # columns to read
    names=True  # column names
)

#Line chart will plot the survival rate by age

df = pd.read_csv('titanic_v2.csv')

leng=0
sums=0

for line in df.Age:
    if line>=0:
        leng=leng+1
        sums=sums+line
    else:
        leng=leng+0
        sums=sums+0

age_rp=int(sums/leng)

a = np.where(df['Age']>=0, df.Age, age_rp)
df['Age']=a.astype(int)


for line in df:
    data_line=df[['PassengerId', 'Survived','Age']]

data_line.to_csv('data-line.csv', index=False)

#Bar chart will show the survival groups by class
data_hist = np.genfromtxt(
    'titanic_v2.csv',  # file name
    names= 'Id, Survival, Class',  # column names
    delimiter=',',  # column delimiter
    usecols=(0,1,2),  # columns to read
    filling_values=0,       # fill missing values with 0
    dtype=['>S100', '>S100', '>S100']  # data type
)

data_hist_file = open('data-hist.csv', "wb")
writer_dh = csv.writer(data_hist_file, delimiter=',')

for line in data_hist:
    writer_dh.writerow(line)

data_hist_file.close()

