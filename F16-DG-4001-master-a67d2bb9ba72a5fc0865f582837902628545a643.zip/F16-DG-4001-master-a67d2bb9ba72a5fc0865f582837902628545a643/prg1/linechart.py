import matplotlib.pyplot as plt
import pandas as pd


df = pd.read_csv('data-line.csv')
df2= pd.DataFrame(df).pivot_table('PassengerId', 'Age', 'Survived', aggfunc=lambda x: len(x.unique()), fill_value=0)

t=df2.unstack(level=0)
dfD=t[0]
dfS=t[1]
dfA=dfD+dfS
pD=(dfD/dfA)*100   #Death percentage by Age
pS=(dfS/dfA)*100   #Survival percentage by Age


plt.plot(pS, color='purple', marker='*')
plt.xlabel('Age')
plt.ylabel('Survival Rate (%)')
plt.title('Titanic Survival Rate by Age')

plt.savefig('linechart.png')
