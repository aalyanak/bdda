In this homework, the dataset of geolocation.csv is used from the link below: 
    | https://d1b10bmlvqabco.cloudfront.net/attach/irqfvh1ctrg2vt/is28edmcmde4ht/iv6f6l0esada/geolocation.csv

Requirements
=====
| os
| re
| codecs

Deliverables
=====

| geolocation.csv (downloaded)  : https://gitlab.com/cloudmesh_fall2016/F16-DG-4001/blob/master/prg-geo/geolocation.csv
| prg-geo.py                    : https://gitlab.com/cloudmesh_fall2016/F16-DG-4001/blob/master/prg-geo/prg-geo.py
| geo_formatted.csv             : https://gitlab.com/cloudmesh_fall2016/F16-DG-4001/blob/master/prg-geo/geo_formatted.csv
| input.txt                     : https://gitlab.com/cloudmesh_fall2016/F16-DG-4001/blob/master/prg-geo/input.txt
| prg-geo.html                  : https://gitlab.com/cloudmesh_fall2016/F16-DG-4001/blob/master/prg-geo/prg-geo.html
| 
| requirements.txt
| README.rst

Usage
=====

| pip install the required packages (list is in requirements.txt)
| Download the geolocation.csv and put to the same folder with prg-geo.py
| Run prg-geo.py, and this will create 2 files: geo_formatted.csv and input.txt

| Copy the input.txt into prg-geo.html var data function:

    |    var data = google.visualization.arrayToDataTable([
    |    
    |    .... input ....
    |    
    |   ]);
        
    
| prg-geo.html visualizes the vacation locations of students (by their current location in the bubble)