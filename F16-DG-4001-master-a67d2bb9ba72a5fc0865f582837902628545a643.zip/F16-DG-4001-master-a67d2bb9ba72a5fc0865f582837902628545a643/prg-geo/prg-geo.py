import os
import re
import codecs

with open("geolocation.csv",'r') as f2:
    with open ("tmp_geo.csv", 'wb') as f3:
        f3.write('Attempt,City,N1,Latitude,N2,Longtitude,N3,Format\n')
        for row in f2:
            sep = 'UTC,'
            head, sep, row1 = row.partition(sep)
            row2=re.sub(r'"[^"]*"', lambda m: m.group(0).replace(',', ''), row1)
            row2=row2.replace('"','').replace('[','').replace(', ','').replace(']','').replace('{','').replace('}','').replace('*','')
            f3.write(row2)
    f3.close()
f2.close()


with codecs.open('tmp_geo.csv', "r",encoding='utf-8', errors='ignore') as f0:
    with open ("geo_formatted.csv", 'wb') as f1:
        for row in f0:
            f1.write(row)
    f1.close()
f0.close()

try:
    os.remove("tmp_geo.csv")
except OSError:
    pass


with open ("geo_formatted.csv", 'r') as f:
    next(f)
    with open("input.txt", 'w') as i:
        i.write('["LATITUDE",	"LONGTITUDE", "LOCATION"],\n')
        for line in f:
            bits = line.split(',')
            r1=''.join(c for c in bits[3] if c.isdigit() or c == '.' or c == ',' or c == ' ').strip()
            r2=''.join(c for c in bits[5] if c.isdigit() or c == '.' or c == ',' or c == ' ').strip()
            sep1 = ' '
            sep2 = ' '
            head1, sep1, tail1 = r1.partition(sep1)
            head2, sep2, tail2 = r2.partition(sep2)
            if len(head1)<1:
                head1=0
            if len(head2)<1:
                head2=0
            inp='['+str(head2)+' ,'+str(head1)+', "'+bits[1]+'"],'
            i.write(inp)
            i.write('\n')
    i.close()
f.close()
